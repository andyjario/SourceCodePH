﻿Imports System.Data.SqlClient
Imports System.Configuration
Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Then
            MessageBox.Show("Please enter required fields!", "Authenticaion Error!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            Dim conn As New System.Data.OleDb.OleDbConnection()
            conn.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=D:\LoginForm\Database\loginform.accdb;User ID=admin"

            Try
                Dim sql As String = "SELECT * FROM member WHERE USERNAME ='" & TextBox1.Text & "' AND PASSWORD ='" & TextBox2.Text & "'"
                Dim sqlCom As New System.Data.OleDb.OleDbCommand(sql)

                sqlCom.Connection = conn
                conn.Open()

                Dim sqlRead As System.Data.OleDb.OleDbDataReader = sqlCom.ExecuteReader()
                If sqlRead.Read() Then
                    Form2.Show()
                    Me.Hide()
                Else
                    MessageBox.Show("Username and passwordd do not match!!", "Authenticaion Failure", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    TextBox1.Text = ""
                    TextBox2.Text = ""

                    TextBox1.Focus()

                End If
            Catch ex As Exception
                MessageBox.Show("Failed to connect to database..", "Database connection Error ", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox1.Focus()

    End Sub
End Class
