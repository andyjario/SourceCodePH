<?php
    include "dbconn.php";
    if(isset($_GET['delete'])){
        $studid=$_GET['delete'];
        $sql="DELETE FROM tbl_student WHERE studid='$studid'";
        if($conn->query($sql)){
            $_SESSION['success']="Successfully deleted";
        }else{
            $_SESSION['error']="Error to delete";
        }
    }
    header("location:record.php");
?>