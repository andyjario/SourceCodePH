 <?php include "session.php";?>
<html>
    <head>
        <title>Student Information System</title>
        <style>
            body{
                margin: 0 auto;
                background-color:#eee;
                font-family:century gothic;
                /* background: linear-gradient(45deg, red, blue); */
                /* background: rgb(2,0,36);
background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(9,9,121,1) 35%, rgba(0,212,255,1) 100%); */
background-image: linear-gradient(to right top, #051937, #004d7a, #008793, #00bf72, #a8eb12);
            }
            ol,li,a{
                float:left;
				margin-right:10px;
                text-decoration:none;
                list-style-type:none;
                color:white;
				text-transform:uppercase;
				
            }
            .container{
				width:1080px;
				margin: 0 auto;
			}
            #menubar{
                padding:5px;
                background: rgb(35, 33, 33);
                overflow:hidden;
				border-radius:5px;
				
            }
            #addForm{
                background:white;
                padding:10px;
                margin: 0 auto;
                margin-top:10px;
                border-radius:5px;
            }
            input[type='text']{
                width:100%;
                padding:5px;
            }
            textarea{
                width:100%;
                padding:5px;
            }
            button[type='submit']{
                padding:10px;
                border:none;
                color:white;
                background-color:crimson;
                margin-top:5px;
                border-radius:5px;
                cursor:pointer;
            }
            button[type='submit']:hover{
                background-color:#f00002;
            }
            button[type='reset']{
                padding:10px;
                border:none;
                color:white;
                background-color:blue;
                margin-top:5px;
                border-radius:5px;
                cursor:pointer;
            }
            button[type='reset']:hover{
                background-color:#1e3799;
            }
            table{
    width: 100%;
    border:1px solid #ccc;
    border-collapse: collapse;
   
}
tr,th,td{
    border:1px solid #ccc;
    padding:5px;
    text-align: left;
}
.pagination a{
    padding: 10px;
    color: #fff;
    background-color: #00bf72;
    margin: 0 auto;
    border-radius: 3px;
}
.pagination ul,li, a{
    text-align: center;
    
}
.pagination a:hover{
    background-color: #05794b;
   
}
.error{
    background-color: #f00002;
    color:#fff;
    padding: 10px;
}
.success{
    background-color: #00bf72;
    color:#fff;
    padding: 10px;
}
.search{
    margin-top:10px;
    
}
#search{
    border-radius:5px;
    border-color:1px solid #ccc;
    border:none;
    padding:10px;
}
#search:focus{
    outline: 2px solid rgb(26, 137, 255);     /* oranges! yey */
  }
.myPagination{
    background-color: #fff;
    overflow: hidden;
   margin-top: 10px;
   border-radius: 3px;
}

        </style>
    </head>
    <body>
        <div class="container">
        <div id="menubar">
        <ol>
                <li><a href="record.php">RECORD</a></li>
                <li><a href="index.php">REGISTER</a></li>
               <li>
					[WELCOME <?=$admin;?>]
					<a style="color:yellow" href="logout.php" onclick="return confirm('Are you sure do you really want to logout?');">LOGOUT</a>
				</li>
            </ol>
        </div>
        <div class="search">
                <input type="text" id="search" placeholder="SEARCH">
            </div>
        <div id="addForm">
            <table id="table">
                <thead> 
                    <th>ID NUMBER</th>
                    <th>FIRST NAME</th>
                    <th>MI</th>
                    <th>LAST NAME</th>
                    <th>GENDER</th>
                    <th>COURSE</th>
                    <th>CONTACT</th>
                    <th>ADDRESS</th>
                    <th>PROFILE</th>
                    <th>ACTIONS</th>
                </thead>
                <tbody>
                    <?php
                    if (isset($_GET['page_no']) && $_GET['page_no']!="") {
                        $page_no = $_GET['page_no'];
                        } else {
                            $page_no = 1;
                        }
                        $total_records_per_page = 5;
                        $offset = ($page_no-1) * $total_records_per_page;
                        $previous_page = $page_no - 1;
                        $next_page = $page_no + 1;
                        $adjacents = "2";

                        $result_count = mysqli_query($conn,"SELECT COUNT(*) As total_records FROM `tbl_student`");
                        $total_records = mysqli_fetch_array($result_count);
                        $total_records = $total_records['total_records'];
                        $total_no_of_pages = ceil($total_records / $total_records_per_page);
                        $second_last = $total_no_of_pages - 1; // total pages minus 1
                    $sql="SELECT * FROM tbl_student LIMIT $offset, $total_records_per_page";
                    $query=$conn->query($sql);
                    while($row=$query->fetch_assoc()){
                    ?>
                        <tr>
                            <td><?php print $row['idnumber'];?></td>
                            <td><?php print $row['fname'];?></td>
                            <td><?php print $row['mi'];?></td>
                            <td><?php print $row['lname'];?></td>
                            <td><?php print $row['gender'];?></td>
                            <td><?php print $row['course'];?></td>
                            <td><?php print $row['contact'];?></td>
                            <td><?php print $row['address'];?></td>
                            <td><img src="<?php print $row['profile'];?>" width="50"></td>
                            <td>
                                <a href="edit.php?edit=<?php print $row['studid'];?>" style="background:#3867d6;padding:5px;border-radius:3px">EDIT</a>
                                <a href="delete.php?delete=<?php print $row['studid'];?>" style="background:#eb3b5a;padding:5px;border-radius:3px" onclick="return confirm ('Are you sure you want to delete this item?')">DELETE</a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
        <div class="myPagination">       
                <ul class="pagination">
                <?php if($page_no > 1){
                echo "<li><a href='?page_no=1'>First</a></li>";
                } ?>
                    
                <li <?php if($page_no <= 1){ echo "class='disabled'"; } ?>>
                <a <?php if($page_no > 1){
                echo "href='?page_no=$previous_page'";
                } ?>>Previous</a>
                </li>
                <li><a style="background:white;color:#000;border:1px solid #aaa">Page <?php echo $page_no." of ".$total_no_of_pages; ?></a></li>
                    
                <li <?php if($page_no >= $total_no_of_pages){
                echo "class='disabled'";
                } ?>>
                <a <?php if($page_no < $total_no_of_pages) {
                echo "href='?page_no=$next_page'";
                } ?>>Next</a>
                </li>

                <?php if($page_no < $total_no_of_pages){
                echo "<li><a href='?page_no=$total_no_of_pages'>Last &rsaquo;&rsaquo;</a></li>";
                } ?>     
                 <br>
                 <br>
            </div>
        </div>
        <script src="//ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
        <script>
            var $rows = $('#table tr');
            $('#search').keyup(function() {
                var val = $.trim($(this).val()).replace(/ +/g, ' ').toLowerCase();

                $rows.show().filter(function() {
                    var text = $(this).text().replace(/\s+/g, ' ').toLowerCase();
                    return !~text.indexOf(val);
                }).hide();
            });
        </script>
    </body>
</html>