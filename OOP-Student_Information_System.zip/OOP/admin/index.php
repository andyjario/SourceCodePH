 <?php include "session.php";?>
<html>
    <head>
        <title>Student Information System</title>
        <style>
            body{
                margin: 0 auto;
                background-color:#eee;
                font-family:century gothic;
                /* background: linear-gradient(45deg, red, blue); */
                /* background: rgb(2,0,36);
background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(9,9,121,1) 35%, rgba(0,212,255,1) 100%); */
background-image: linear-gradient(to right top, #051937, #004d7a, #008793, #00bf72, #a8eb12);
            }
            ol,li,a{
                float:left;
				margin-right:10px;
                text-decoration:none;
                list-style-type:none;
                color:white;
				text-transform:uppercase;
				
            }
            .container{
				width:1080px;
				margin: 0 auto;
			}
            #menubar{
                padding:5px;
                background: rgb(35, 33, 33);
                overflow:hidden;
				border-radius:5px;
				
            }
            #addForm{
                background:white;
                padding:10px;
                margin: 0 auto;
                margin-top:10px;
                border-radius:5px;
            }
            input[type='text'],input[type='date'],select{
                width:100%;
                padding:5px;
                border: 1px solid #ccc;
                border-radius: 3px;
                padding: 10px;
            }
            input[type="text"]:focus{
                outline: 2px solid rgb(26, 137, 255);     /* oranges! yey */
            }
            textarea{
                width:100%;
                padding:5px;
            }
            button[type='submit']{
                padding:10px;
                border:none;
                color:white;
                background-color:crimson;
                margin-top:5px;
                border-radius:5px;
                cursor:pointer;
            }
            button[type='submit']:hover{
                background-color:#f00002;
            }
            button[type='reset']{
                padding:10px;
                border:none;
                color:white;
                background-color:blue;
                margin-top:5px;
                border-radius:5px;
                cursor:pointer;
            }
            button[type='reset']:hover{
                background-color:#1e3799;
            }
            .error{
        background-color: #f00002;
        color:#fff;
        padding: 10px;
        }
        .success{
            background-color: #00bf72;
            color:#fff;
            padding: 10px;
        }
        </style>
    </head>
    <body>
        <div class="container">
        <div id="menubar">
        <ol>
                <li><a href="record.php">RECORD</a></li>
                <li><a href="index.php">REGISTER</a></li>
                <li>
					[WELCOME <?=$admin;?>]
					<a style="color:yellow" href="logout.php" onclick="return confirm('Are you sure do you really want to logout?');">LOGOUT</a>
				</li>
            </ol>
        </div>
         
        <div id="addForm">
        <?php
                    if(isset($_SESSION['success'])){
                        echo "<div class='success'>".$_SESSION['success']."</div>";
                        unset($_SESSION['success']);
                    }
                    if(isset($_SESSION['error'])){
                        echo "<div class='error'>".$_SESSION['error']."</div>";
                        unset($_SESSION['error']);
                    }
                ?>
            <form action="register_save.php" method="POST" enctype="multipart/form-data">
                <label for="">ID Number</label><br>
                <input type="text" name="idnumber"><br>
                <label for="">First Name</label><br>
                <input type="text" name="fname"><br>
                <label for="">Middle Name</label><br>
                <input type="text" name="mi"><br>
                <label for="">Last Name</label><br>
                <input type="text" name="lname"><br>
                <label for="">Gender</label><br>
                <input type="radio" name="gender" value="Male">Male <br>
                <input type="radio" name="gender" value="Female">Female <br>
                <label for="">Course</label><br>
                <input type="text" name="course"><br>
                <label for="">Contact</label><br>
                <input type="text" name="contact"><br>
                <label for="">Address</label><br>
                <textarea name="address" row="8"></textarea><br>
                <label for="">Profile</label><br>
                <input type="file" name="profile"><br>
                <button type="submit" name="submit">Submit</button>
                <button type="reset">Cancel</button>
            </form>
        </div>
        </div>
    </body>
</html>