<?php
    include "dbconn.php";

    if(isset($_POST['submit'])){
        $studid=$_POST['studid'];
        $idnumber=$_POST['idnumber'];
        $fname=$_POST['fname'];
        $mi=$_POST['mi'];
        $lname=$_POST['lname'];
        $gender=$_POST['gender'];
        $course=$_POST['course'];
        $contact=$_POST['contact'];
        $address=$_POST['address'];
        $file_name=$_FILES['profile']['name'];
        $file_temp=$_FILES['profile']['tmp_name'];
        $file_size=$_FILES['profile']['size'];
        $location='upload/'.$file_name;

        if($file_size<=1000000){
            if(empty($_FILES['profile']['name'])) {
                $sql="UPDATE tbl_student SET
                idnumber='$idnumber',
                fname='$fname',
                mi='$mi',
                lname='$lname',
                gender='$gender',
                course='$course',
                contact='$contact',
                address='$address'
                WHERE studid='$studid'";
                if($conn->query($sql)){
                    $_SESSION['success']="Student has been updated successfully";
                }else{
                    $_SESSION['error']="Error to save";
                }

            }else{
                move_uploaded_file($file_temp,$location);
                $sql="UPDATE tbl_student SET
                idnumber='$idnumber',
                fname='$fname',
                mi='$mi',
                lname='$lname',
                gender='$gender',
                course='$course',
                contact='$contact',
                address='$address',
                profile='$location'
                WHERE studid='$studid'";
                if($conn->query($sql)){
                    $_SESSION['success']="Student has been updated successfully";
                }else{
                    $_SESSION['error']="Error to save";
                }
            }

        }else{
            $_SESSION['error']="Image is to large to save";
        }
    }
    $conn->close();
    header("location:record.php");
?>