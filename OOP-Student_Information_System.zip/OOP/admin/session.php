<?php
	date_default_timezone_set('Asia/Manila');
	
	include 'dbconn.php';

	if(!isset($_SESSION['admin']) || trim($_SESSION['admin']) == ''){
		header('location: ../index.php');
	}
	
	$sql = "SELECT * FROM tbl_users WHERE userid = '".$_SESSION['admin']."'";
	$query = $conn->query($sql);
	if($query->num_rows >0){
		$user = $query->fetch_assoc();
		$admin =$user['lname'].', '.$user['fname'].' '.$user['mname'];
		
	}else{
		header("locations: ../index.php");
	}

?>