<?php
    include "dbconn.php";
    if(isset($_GET['delete'])){
        $itemid=$_GET['delete'];
        $sql="DELETE FROM tbl_supply WHERE id='$itemid'";
        if($conn->query($sql)){
            $_SESSION['success']="Successfully deleted";
        }else{
            $_SESSION['error']="Error to delete";
        }
    }
    header("location:item.php");
?>