<?php
	///session_start();
	include 'app/dbconn.php';

	if(isset($_POST['submit'])){
		$username = $_POST['username'];
		$password = $_POST['password'];

		$sql1 = "SELECT * FROM tbl_users WHERE username='$username'";
		$query1 = $conn->query($sql1);
		if($query1->num_rows > 0){
			$row = $query1->fetch_assoc();
			if($password==$row['password']){
				$_SESSION['admin'] = $row['userid'];	
				header('location:app/index.php?dashboard=home');
			}else{
				$_SESSION['error'] = 'Incorrect password';
				header('location: index.php?error=error');
			}
		}else{
			header('location: index.php?error=error');
			$_SESSION['error'] = 'username or password not found!';
		}
		
	}else{
		$_SESSION['error'] = 'username or password not found!';
		header('location: index.php?error=error');
	}
?>