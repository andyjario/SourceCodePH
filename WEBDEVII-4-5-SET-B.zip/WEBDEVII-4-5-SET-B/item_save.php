<?php
    include "dbconn.php";

    if(isset($_POST['submit'])){

        $itemid=$_POST['itemid'];
        $itembrand=$_POST['itembrand'];
        $itemname=$_POST['itemname'];
        $itemdesc=$_POST['itemdesc'];
        $itemqty=$_POST['itemqty'];
        $itemprice=$_POST['itemprice'];
        $daterecieved=$_POST['daterecieved'];
        $file_name=$_FILES['image']['name'];
        $file_temp=$_FILES['image']['tmp_name'];
        $file_size=$_FILES['image']['size'];
        $location='upload/'.$file_name;

        if($file_size<=1000000){
            move_uploaded_file($file_temp,$location);
            $sql="INSERT INTO tbl_supply(itemid,itembrand,itemname,itemdesc,itemqty,itemprice,daterecieved,image)
            VALUES('$itemid','$itembrand','$itemname','$itemdesc','$itemqty','$itemprice','$daterecieved','$location')";
            if($conn->query($sql)){
                $_SESSION['success']="New item has successfully saved!";
            }else{
                $_SESSION['error']="Error to save";
            }
        }else{
            $_SESSION['error']="Image is to large to save";
        }
    }
    $conn->close();
    header("location:index.php");
?>