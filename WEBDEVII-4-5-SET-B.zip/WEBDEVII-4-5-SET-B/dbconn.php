<?php
    session_start();
    $servername="localhost";
    $username="root";
    $password="";
    $dbname="webdevii_45_setb";
    $conn=new mysqli($servername,$username,$password,$dbname);
    if($conn->connect_error){
        echo "Database not connected";
    }
?>