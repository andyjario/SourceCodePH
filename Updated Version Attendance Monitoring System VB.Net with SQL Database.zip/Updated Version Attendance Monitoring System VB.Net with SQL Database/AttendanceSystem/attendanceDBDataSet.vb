﻿Partial Class attendanceDBDataSet
End Class
