﻿Imports System.Data.SqlClient
Public Class AdminEmpTimInForm
    Private Sub AdminEmpTimInForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim query As String = "SELECT * FROM AttendanceRecord WHERE DATE ='" & DateAndTime.Now.ToString("dd/MM/yyyy") & "'"
        Using conn As SqlConnection = New SqlConnection("Data Source=.;Initial Catalog=attendanceDB;Integrated Security=True;Pooling=False")
            Using resultcmd As SqlCommand = New SqlCommand(query, conn)
                Using sda As SqlDataAdapter = New SqlDataAdapter()
                    sda.SelectCommand = resultcmd
                    Using dt As New DataTable()
                        sda.Fill(dt)
                        DataGridView1.DataSource = dt
                        DataGridView1.GridColor = Color.Red
                        DataGridView1.CellBorderStyle = DataGridViewCellBorderStyle.None
                        DataGridView1.BackgroundColor = Color.LightGray

                        DataGridView1.DefaultCellStyle.SelectionBackColor = Color.Red
                        DataGridView1.DefaultCellStyle.SelectionForeColor = Color.White

                        DataGridView1.DefaultCellStyle.WrapMode = DataGridViewTriState.[True]

                        DataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect
                        DataGridView1.AllowUserToResizeColumns = False

                        DataGridView1.RowsDefaultCellStyle.BackColor = Color.Bisque
                        DataGridView1.AlternatingRowsDefaultCellStyle.BackColor = Color.Beige
                        DataGridView1.Columns(0).Visible = True
                        DataGridView1.Columns(1).Width = 170
                        DataGridView1.Columns(2).Width = 190
                        DataGridView1.Columns(3).Width = 190

                    End Using
                End Using
            End Using
        End Using
        Try

            Dim mycon As New SqlConnection("Data Source=.;Initial Catalog=attendanceDB;Integrated Security=True;Pooling=False")
            mycon.Open()
            Dim da As New SqlDataAdapter("SELECT * FROM UserTable WHERE USERTYPE='User'", mycon)
            Dim dt As New DataTable
            da.Fill(dt)
            ComboBox1.DataSource = dt
            ComboBox1.DisplayMember = "USERNAME"
            ComboBox1.ValueMember = "USERNAME"
            mycon.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim query As String = "SELECT * FROM AttendanceRecord WHERE USERNAME ='" & ComboBox1.SelectedValue & "' AND DATE ='" & DateAndTime.Now.ToString("dd/MM/yyyy") & "'"
        Using con As SqlConnection = New SqlConnection("Data Source=.;Initial Catalog=attendanceDB;Integrated Security=True;Pooling=False")
            Using cmd As SqlCommand = New SqlCommand(query, con)
                Using sda As New SqlDataAdapter()
                    sda.SelectCommand = cmd
                    Using dt As New DataTable()
                        sda.Fill(dt)
                        DataGridView1.DataSource = dt
                    End Using
                End Using
            End Using
        End Using
    End Sub
End Class