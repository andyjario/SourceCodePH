﻿Imports System.Data.SqlClient
Imports System.IO.File
Public Class EmpProfile

    Shared Property EmProfile As String

    Private Sub EmpProfile_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        TextBox1.Text = EmProfile
        Dim query As String = "SELECT * FROM UserTable WHERE USERNAME='" & TextBox1.Text & "'"
        Using con As SqlConnection = New SqlConnection("Data Source=.;Initial Catalog=attendanceDB;Integrated Security=True;Pooling=False")
            Using cmd As SqlCommand = New SqlCommand(query, con)
                Using da As New SqlDataAdapter()
                    da.SelectCommand = cmd
                    Using dt As New DataTable()
                        con.Open()
                        da.Fill(dt)
                        If dt.Rows.Count > 0 Then
                            TextBox1.Text = dt.Rows(0)(0).ToString()
                            TextBox2.Text = dt.Rows(0)(3).ToString()
                            TextBox3.Text = dt.Rows(0)(4).ToString()
                            ComboBox1.Text = dt.Rows(0)(5).ToString()
                            TextBox4.Text = dt.Rows(0)(6).ToString()
                            DateTimePicker1.Text = dt.Rows(0)(7).ToString
                            TextBox6.Text = dt.Rows(0)(8).ToString
                            If TextBox6.Text = "" Then
                                PictureBox1.Hide()
                            Else
                                PictureBox1.Show()
                            End If
                        Else
                            TextBox1.Text = ""
                            TextBox2.Text = ""
                            TextBox3.Text = ""
                            TextBox4.Text = ""
                            ComboBox1.Items.Clear()
                        End If
                        BindData()
                    End Using
                    con.Close()
                End Using
            End Using
        End Using

    End Sub
    Public Sub BindData()
        TextBox5.Text = ""
        TextBox5.AppendText(vbTab + vbTab + vbTab + vbTab + vbTab + vbTab & "INFORMATION" + vbNewLine)
        TextBox5.AppendText("" + vbNewLine)
        TextBox5.AppendText("" + vbNewLine)
        TextBox5.AppendText("First Name: " + vbTab & TextBox2.Text & " " & TextBox3.Text + vbNewLine)
        TextBox5.AppendText("Gender: " + vbTab + vbTab & ComboBox1.Text + vbNewLine)
        TextBox5.AppendText("Age: " + vbTab + vbTab & TextBox4.Text + vbNewLine)
        TextBox5.AppendText("Birth Date: " + vbTab & DateTimePicker1.Text + vbNewLine)
        TextBox5.AppendText("" + vbNewLine)
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim USERNAME As String = TextBox1.Text
        Dim FIRSTNAME As String = TextBox2.Text
        Dim LASTNAME As String = TextBox3.Text
        Dim GENDER As String = ComboBox1.SelectedItem
        Dim AGE As String = TextBox4.Text
        Dim BIRTHDATE As DateTime = DateTimePicker1.Value
        Dim PHOTO As String = TextBox6.Text
        If TextBox2.Text = Nothing Or TextBox3.Text = Nothing Or TextBox4.Text = Nothing Then
            MessageBox.Show("PLEASE ENTER THE REQUIRED FIELDS!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            Try
                Dim updatequery As String = "UPDATE UserTable SET FIRSTNAME =@FIRSTNAME, LASTNAME =@LASTNAME, GENDER =@GENDER, AGE =@AGE, BIRTHDATE =@BIRTHDATE, PHOTO =@PHOTO WHERE USERNAME=@USERNAME"
                Using updatecon As SqlConnection = New SqlConnection("Data Source=.;Initial Catalog=attendanceDB;Integrated Security=True;Pooling=False")
                    Using cmdupdate As New SqlCommand(updatequery, updatecon)
                        cmdupdate.Parameters.AddWithValue("@USERNAME", USERNAME)
                        cmdupdate.Parameters.AddWithValue("@FIRSTNAME", FIRSTNAME)
                        cmdupdate.Parameters.AddWithValue("@LASTNAME", LASTNAME)
                        cmdupdate.Parameters.AddWithValue("@GENDER", GENDER)
                        cmdupdate.Parameters.AddWithValue("@AGE", AGE)
                        cmdupdate.Parameters.AddWithValue("@BIRTHDATE", BIRTHDATE)
                        cmdupdate.Parameters.AddWithValue("@PHOTO", PHOTO)
                        updatecon.Open()
                        cmdupdate.ExecuteNonQuery()
                        MessageBox.Show("SUCCESSFULY UPDATED", "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        updatecon.Close()
                        BindData()
                    End Using
                    Me.Refresh()
                End Using
            Catch ex As Exception
                MessageBox.Show("OPPS, WE HAVE ERROR FOUND", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    Private Sub DateTimePicker1_ValueChanged(sender As Object, e As EventArgs) Handles DateTimePicker1.ValueChanged
        Dim YR As Integer = DateDiff(DateInterval.Year, DateTimePicker1.Value, Now)
        Dim Month As Integer = DateDiff(DateInterval.Month, DateTimePicker1.Value, Now) Mod 12
        Dim Day As Integer = DateDiff(DateInterval.Day, DateTimePicker1.Value, Now) Mod 30 - 10
        TextBox4.Text = YR & "Years," & Month & "Months"
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        On Error GoTo Err
        OpenFileDialog1.ShowDialog()
        TextBox6.Text = OpenFileDialog1.FileName
Err:
        Exit Sub
    End Sub

    Private Sub TextBox6_TextChanged(sender As Object, e As EventArgs) Handles TextBox6.TextChanged
        If (System.IO.File.Exists(TextBox6.Text)) Then
            PictureBox1.Image = Image.FromFile(TextBox6.Text)
        End If
        If TextBox6.Text = "" Then
            PictureBox1.Hide()
        Else
            PictureBox1.Show()
        End If
    End Sub
End Class