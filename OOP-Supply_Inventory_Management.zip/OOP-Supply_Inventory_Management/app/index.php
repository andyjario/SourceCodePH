<?php include "session.php";?>
<html>
    <head>
        <title>Inventory Management System</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <div class="container">
            <div class="menubar">
                <ol>
                    <li><a href="item.php">Record</a></li>
                    <li><a href="index.php">Add New</a></li>
                </ol>
				<div style="float: right">
					<a href="index.php" style="color:yellow">Welcome <?=$admin;?></a>
					<a href="logout.php" onclick="return confirm('Are you sure do you really want to logout?');">Logout</a>
				</div>
            </div>
            <div class="addForm">
             <?php
                    if(isset($_SESSION['success'])){
                        echo "<div class='success alert'>".$_SESSION['success']."</div>";
                        unset($_SESSION['success']);
                    }
                    if(isset($_SESSION['error'])){
                        echo "<div class='error alert'>".$_SESSION['error']."</div>";
                        unset($_SESSION['error']);
                    }
                ?>
                <form action="item_save.php" method="POST" enctype="multipart/form-data">
                    <label for="">Item Id</label><br>
                    <input type="text" name="itemid"><br>
                    <label for="">Item Brand</label><br>
                    <select name="itembrand">
                        <option value="">Select Brand</option>
                        <option value="APPLE LAPTOPS">APPLE LAPTOPS</option>
                        <option value="ASUS">ASUS</option>
                        <option value="AVITA">AVITA</option>
                        <option value="CLEVO">CLEVO</option>
                        <option value="COMPAQ">COMPAQ</option>
                        <option value="DELL">DELL</option>
                        <option value="ELITEGROUP COMPUTER SYSTEMS">ELITEGROUP COMPUTER SYSTEMS</option>
                        <option value="FUJITSU">FUJITSU</option>
                        <option value="GATEWAY">GATEWAY</option>
                        <option value="HP">HP</option>
                        <option value="IBM">IBM</option>
                        <option value="LENOVO">LENOVO</option>
                        <option value="MICROSOFT">MICROSOFT</option>
                        <option value="MSI">MSI</option>
                        <option value="RAZER">RAZER</option>
                        <option value="SAMSUNG">SAMSUNG</option>
                        <option value="SONY">SONY</option>
                        <option value="TOSHIBA">TOSHIBA</option>
                    </select>
                    <br>
                    <label for="">Item Name</label><br>
                    <input type="text" name="itemname"><br>
                    <label for="">Item Description</label><br>
                    <input type="text" name="itemdesc"><br>
                    <label for="">Item Quantity</label><br>
                    <input type="text" name="itemqty"><br>
                    <label for="">Item Price</label><br>
                    <input type="text" name="itemprice"><br>
                    <label for="">Date Recieved</label><br>
                    <input type="date" name="daterecieved"><br>
                    <label for="">Image</label><br>
                    <input type="file" name="image"><br>
                    <button type="submit" name="submit">Submit</button>
                    <button type="reset">Cancel</button>
                </form>
            </div>
        </div>
        <script src="js/jquery.min.js"></script>
        <script type="text/javascript">
        $(document).ready(function () {
        window.setTimeout(function() {
            $(".alert").fadeTo(1000, 0).slideUp(1000, function(){
                $(this).remove(); 
            });
        }, 5000);

        });
    </script>
    </body>
</html>