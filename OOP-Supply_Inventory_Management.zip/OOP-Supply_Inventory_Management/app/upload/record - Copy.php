<?php
    include "dbconn.php";
?>
<html>
    <head>
        <title>Inventory Management System</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <div class="container">
            <div class="menubar">
                <ol>
                    <li><a href="record.php">Record</a></li>
                    <li><a href="index.php">Add New</a></li>
                    <li><a href="">Brand</a></li>
                    <li><a href="">Category</a></li>
                    <li><a href="">Search</a></li>
                    <li><a href="">Logout</a></li>
                </ol>
            </div>
            
            <div class="search">
                <input type="text" id="search" placeholder="SEARCH">
            </div>
            <div class="addForm">
                <?php
                    if(isset($_SESSION['success'])){
                        echo "<div class='success'>".$_SESSION['success']."</div>";
                        unset($_SESSION['success']);
                    }
                    if(isset($_SESSION['error'])){
                        echo "<div class='error'>".$_SESSION['error']."</div>";
                        unset($_SESSION['error']);
                    }
                ?>
            <table id="table">
                <thead>
                    <th>ID</th>
                    <th>BRAND</th>
                    <th>NAME</th>
                    <th>DESCRIPTION</th>
                    <th>QUANTITY</th>
                    <th>PRICE</th>
                    <th>DATE RECIEVED</th>
                    <th>IMAGE</th>
                    <th>ACTIONS</th>
                </thead>
                <tbody>
                    <?php
                        if (isset($_GET['pageno'])) {
                            $pageno = $_GET['pageno'];
                        } else {
                            $pageno = 1;
                        }
                        $no_of_records_per_page = 5;
                        $offset = ($pageno-1) * $no_of_records_per_page;

                        $total_pages_sql = "SELECT COUNT(*) FROM tbl_supply";
        $result = mysqli_query($conn,$total_pages_sql);
        $total_rows = mysqli_fetch_array($result)[0];
        $total_pages = ceil($total_rows / $no_of_records_per_page);


                        $sql="SELECT * FROM tbl_supply LIMIT $offset, $no_of_records_per_page";
                        $query=$conn->query($sql);
                        while($row=$query->fetch_assoc()){
                    ?>
                        <tr>
                            <td><?php print $row['itemid'];?></td>
                            <td><?php print $row['itembrand'];?></td>
                            <td><?php print $row['itemname'];?></td>
                            <td><?php print $row['itemdesc'];?></td>
                            <td><?php print $row['itemqty'];?></td>
                            <td><?php print $row['itemprice'];?></td>
                            <td><?php print $row['daterecieved'];?></td>
                            <td><img src="<?php print $row['image'];?>" width="100"></td>
                            <td>
                                <a href="" style="background:#3867d6;padding:5px;border-radius:3px">EDIT</a>
                                <a href="delete.php?id=<?php print $row['id'];?>" style="background:#eb3b5a;padding:5px;border-radius:3px" onclick="return confirm ('Are you sure you want to delete this item?')">DELETE</a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="9">
                        <ul class="pagination">
                            <li><a href="?pageno=1">First</a></li>
                            <li class="<?php if($pageno <= 1){ echo 'disabled'; } ?>">
                                <a href="<?php if($pageno <= 1){ echo '#'; } else { echo "?pageno=".($pageno - 1); } ?>">Prev</a>
                            </li>
                            <li class="<?php if($pageno >= $total_pages){ echo 'disabled'; } ?>">
                                <a href="<?php if($pageno >= $total_pages){ echo '#'; } else { echo "?pageno=".($pageno + 1); } ?>">Next</a>
                            </li>
                            <li><a href="?pageno=<?php echo $total_pages; ?>">Last</a></li>
                          </ul>
                        </td>
                    </tr>
                </tfoot>
            </table>
            </div>
        </div>
        <script src="//ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
        <script>
            var $rows = $('#table tr');
            $('#search').keyup(function() {
                var val = $.trim($(this).val()).replace(/ +/g, ' ').toLowerCase();

                $rows.show().filter(function() {
                    var text = $(this).text().replace(/\s+/g, ' ').toLowerCase();
                    return !~text.indexOf(val);
                }).hide();
            });
        </script>
    </body>
</html>