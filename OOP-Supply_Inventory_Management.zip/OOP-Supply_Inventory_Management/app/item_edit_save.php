<?php
    include "dbconn.php";

    if(isset($_POST['submit'])){
        $id=$_POST['id'];
        $itemid=$_POST['itemid'];
        $itembrand=$_POST['itembrand'];
        $itemname=$_POST['itemname'];
        $itemdesc=$_POST['itemdesc'];
        $itemqty=$_POST['itemqty'];
        $itemprice=$_POST['itemprice'];
        $daterecieved=$_POST['daterecieved'];
        $file_name=$_FILES['image']['name'];
        $file_temp=$_FILES['image']['tmp_name'];
        $file_size=$_FILES['image']['size'];
        $location='upload/'.$file_name;

        if($file_size<=1000000){
            if(empty($_FILES['image']['name'])) {
                $sql="UPDATE tbl_supply SET
                itemid='$itemid',
                itembrand='$itembrand',
                itemname='$itemname',
                itemdesc='$itemdesc',
                itemqty='$itemqty',
                itemprice='$itemprice',
                daterecieved='$daterecieved'
                WHERE id='$id'";
                if($conn->query($sql)){
                    $_SESSION['success']="item has been updated successfully saved!";
                }else{
                    $_SESSION['error']="Error to save";
                }

            }else{
                move_uploaded_file($file_temp,$location);
                $sql="UPDATE tbl_supply SET
                itemid='$itemid',
                itembrand='$itembrand',
                itemname='$itemname',
                itemdesc='$itemdesc',
                itemqty='$itemqty',
                itemprice='$itemprice',
                daterecieved='$daterecieved',
                image='$location'
                WHERE id='$id'";
                if($conn->query($sql)){
                    $_SESSION['success']="item has been updated successfully saved!";
                }else{
                    $_SESSION['error']="Error to save";
                }
            }

        }else{
            $_SESSION['error']="Image is to large to save";
        }
    }
    $conn->close();
    header("location:item.php");
?>