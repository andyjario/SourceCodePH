<?php
    session_start();
    $servername="localhost";
    $username="root";
    $password="";
    $dbname="webdevii";
    $conn=new mysqli($servername,$username,$password,$dbname);
    if($conn->connect_error){
        echo "Database not connected";
    }

?>