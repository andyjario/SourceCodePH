<?php
    include "dbconn.php";
?>
<html>
    <head>
        <title>Inventory Management System</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <div class="container">
            <div class="menubar">
                <ol>
                    <li><a href="item.php">Record</a></li>
                    <li><a href="index.php">Add New</a></li>
                    <li><a href="">Logout</a></li>
                </ol>
            </div>
            
            <div class="search">
                <input type="text" id="search" placeholder="SEARCH">
            </div>
            <div class="addForm">
                <?php
                    if(isset($_SESSION['success'])){
                        echo "<div class='success alert'>".$_SESSION['success']."</div>";
                        unset($_SESSION['success']);
                    }
                    if(isset($_SESSION['error'])){
                        echo "<div class='error alert'>".$_SESSION['error']."</div>";
                        unset($_SESSION['error']);
                    }
                ?>
            <table id="table">
                <thead>
                    <th>ID</th>
                    <th>BRAND</th>
                    <th>NAME</th>
                    <th>DESCRIPTION</th>
                    <th>QUANTITY</th>
                    <th>PRICE</th>
                    <th>DATE RECIEVED</th>
                    <th>IMAGE</th>
                    <th>ACTIONS</th>
                </thead>
                <tbody>
                    <?php
                       if (isset($_GET['page_no']) && $_GET['page_no']!="") {
                        $page_no = $_GET['page_no'];
                        } else {
                            $page_no = 1;
                        }
                        $total_records_per_page = 5;
                        $offset = ($page_no-1) * $total_records_per_page;
                        $previous_page = $page_no - 1;
                        $next_page = $page_no + 1;
                        $adjacents = "2";

                        $result_count = mysqli_query($conn,"SELECT COUNT(*) As total_records FROM `tbl_supply`");
                        $total_records = mysqli_fetch_array($result_count);
                        $total_records = $total_records['total_records'];
                        $total_no_of_pages = ceil($total_records / $total_records_per_page);
                        $second_last = $total_no_of_pages - 1; // total pages minus 1

                        $sql="SELECT * FROM tbl_supply LIMIT $offset, $total_records_per_page";
                        $query=$conn->query($sql);
                       
                        while($row=$query->fetch_assoc()){
                    ?>
                        <tr>
                           
                            <td><?php print $row['itemid'];?></td>
                            <td><?php print $row['itembrand'];?></td>
                            <td><?php print $row['itemname'];?></td>
                            <td><?php print $row['itemdesc'];?></td>
                            <td><?php print $row['itemqty'];?></td>
                            <td><?php print $row['itemprice'];?></td>
                            <td><?php print $row['daterecieved'];?></td>
                            <td><img src="<?php print $row['image'];?>" width="100"></td>
                            <td>
                                <a href="item_edit.php?edit=<?php print $row['id'];?>" style="background:#3867d6;padding:5px;border-radius:3px">EDIT</a>
                                <a href="item_delete.php?delete=<?php print $row['id'];?>" style="background:#eb3b5a;padding:5px;border-radius:3px" onclick="return confirm ('Are you sure you want to delete this item?')">DELETE</a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
            </div>

            <div class="myPagination">       
                <ul class="pagination">
                <?php if($page_no > 1){
                echo "<li><a href='?page_no=1'>First</a></li>";
                } ?>
                    
                <li <?php if($page_no <= 1){ echo "class='disabled'"; } ?>>
                <a <?php if($page_no > 1){
                echo "href='?page_no=$previous_page'";
                } ?>>Previous</a>
                </li>
                <li><a style="background:white;color:#000;border:1px solid #aaa">Page <?php echo $page_no." of ".$total_no_of_pages; ?></a></li>
                    
                <li <?php if($page_no >= $total_no_of_pages){
                echo "class='disabled'";
                } ?>>
                <a <?php if($page_no < $total_no_of_pages) {
                echo "href='?page_no=$next_page'";
                } ?>>Next</a>
                </li>

                <?php if($page_no < $total_no_of_pages){
                echo "<li><a href='?page_no=$total_no_of_pages'>Last &rsaquo;&rsaquo;</a></li>";
                } ?>     
                 <br>
                 <br>
            </div>
           
        </div>
		<!---<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>--->
        <script src="js/jquery.min.js"></script>
        <script>
            var $rows = $('#table tr');
            $('#search').keyup(function() {
                var val = $.trim($(this).val()).replace(/ +/g, ' ').toLowerCase();

                $rows.show().filter(function() {
                    var text = $(this).text().replace(/\s+/g, ' ').toLowerCase();
                    return !~text.indexOf(val);
                }).hide();
            });
        </script>
        <script type="text/javascript">
	$(document).ready(function () {
	window.setTimeout(function() {
		$(".alert").fadeTo(1000, 0).slideUp(1000, function(){
			$(this).remove(); 
		});
	}, 5000);

	});
</script>
    </body>
</html>