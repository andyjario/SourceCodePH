-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 29, 2024 at 02:49 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webdevii`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_supply`
--

CREATE TABLE `tbl_supply` (
  `id` int(11) NOT NULL,
  `itemid` varchar(255) NOT NULL,
  `itembrand` text NOT NULL,
  `itemname` text NOT NULL,
  `itemdesc` text NOT NULL,
  `itemqty` int(50) NOT NULL,
  `itemprice` varchar(255) NOT NULL,
  `daterecieved` date DEFAULT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_supply`
--

INSERT INTO `tbl_supply` (`id`, `itemid`, `itembrand`, `itemname`, `itemdesc`, `itemqty`, `itemprice`, `daterecieved`, `image`) VALUES
(6, '99990230', 'COMPAQ', 'DESKTOP', 'COMPUTER SET', 10, '8000', '2024-05-21', 'upload/download (1).jpeg'),
(7, '874445', 'FUJITSU', 'RAM', 'SERT', 3, '1000', '2024-05-21', 'upload/download (5).jpeg'),
(8, '998855', 'ACER', 'VIDEO CARD', 'VIDEO AUS', 10, '900', '2024-05-21', 'upload/download (3).jpeg'),
(10, '1121212', 'ACER', 'DESKTOP', 'COMPUTER SET', 22, '2232', '2024-05-27', 'upload/download (4).jpeg'),
(12, '874445', 'ASUS', 'RAM', '', 3, '1000', '2024-05-21', 'upload/download (5).jpeg'),
(13, '998855', 'ACER', 'VIDEO CARD', 'VIDEO AUS', 10, '900', '2024-05-21', 'upload/download (3).jpeg'),
(14, '1121212', 'ACER', 'DESKTOP', 'COMPUTER SET', 22, '2232', '2024-05-27', 'upload/download (4).jpeg'),
(15, '99990230', 'ASUS', 'DESKTOP', 'COMPUTER SET', 10, '8000', '2024-05-21', 'upload/download.jpeg'),
(16, '874445', 'ASUS', 'RAM', '', 3, '1000', '2024-05-21', 'upload/download (5).jpeg'),
(17, '998855', 'ACER', 'VIDEO CARD', 'VIDEO AUS', 10, '900', '2024-05-21', 'upload/download (3).jpeg'),
(18, '1121212', 'ACER', 'DESKTOP', 'COMPUTER SET', 22, '2232', '2024-05-27', 'upload/download (4).jpeg'),
(19, '99990230', 'ASUS', 'DESKTOP', 'COMPUTER SET', 10, '8000', '2024-05-21', 'upload/download.jpeg'),
(20, '874445', 'ASUS', 'RAM', '', 3, '1000', '2024-05-21', 'upload/download (5).jpeg'),
(21, '998855', 'ACER', 'VIDEO CARD', 'VIDEO AUS', 10, '900', '2024-05-21', 'upload/download (3).jpeg'),
(22, '1121212', 'ACER', 'DESKTOP', 'COMPUTER SET', 22, '2232', '2024-05-27', 'upload/download (4).jpeg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_supply`
--
ALTER TABLE `tbl_supply`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_supply`
--
ALTER TABLE `tbl_supply`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
