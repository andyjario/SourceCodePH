<?php include "dbconn.php";?>
<html>
    <head>
        <title>Inventory Management System</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <div class="container">
            <div class="menubar">
                <ol>
                    <li><a href="item.php">Record</a></li>
                    <li><a href="index.php">Add New</a></li>
                    <li><a href="">Logout</a></li>
                </ol>
            </div>
            <div class="addForm">
                <?php
                if(isset($_GET['edit'])){
                    $id =$_GET['edit'];
                    $sql="SELECT * FROM tbl_supply WHERE id ='$id'";
                    $query=$conn->query($sql);
                    $row=$query->fetch_assoc();
                ?>
                <form action="item_edit_save.php" method="POST" enctype="multipart/form-data">
                    <label for="">Item Id</label><br>
                    <input type="hidden" name="id" value="<?=$row['id'];?>">
                    <input type="text" value="<?=$row['itemid'];?>" name="itemid"><br>
                    <label for="">Item Brand</label><br>
                    <select name="itembrand">
                        <option value=""><?=$row['itembrand'];?></option>
                        <option value="APPLE LAPTOPS">APPLE LAPTOPS</option>
                        <option value="ASUS">ASUS</option>
                        <option value="AVITA">AVITA</option>
                        <option value="CLEVO">CLEVO</option>
                        <option value="COMPAQ">COMPAQ</option>
                        <option value="DELL">DELL</option>
                        <option value="ELITEGROUP COMPUTER SYSTEMS">ELITEGROUP COMPUTER SYSTEMS</option>
                        <option value="FUJITSU">FUJITSU</option>
                        <option value="GATEWAY">GATEWAY</option>
                        <option value="HP">HP</option>
                        <option value="IBM">IBM</option>
                        <option value="LENOVO">LENOVO</option>
                        <option value="MICROSOFT">MICROSOFT</option>
                        <option value="MSI">MSI</option>
                        <option value="RAZER">RAZER</option>
                        <option value="SAMSUNG">SAMSUNG</option>
                        <option value="SONY">SONY</option>
                        <option value="TOSHIBA">TOSHIBA</option>
                    </select>
                    <br>
                    <label for="">Item Name</label><br>
                    <input type="text" value="<?=$row['itemname'];?>" name="itemname"><br>
                    <label for="">Item Description</label><br>
                    <input type="text" value="<?=$row['itemdesc'];?>" name="itemdesc"><br>
                    <label for="">Item Quantity</label><br>
                    <input type="text" value="<?=$row['itemqty'];?>" name="itemqty"><br>
                    <label for="">Item Price</label><br>
                    <input type="text" value="<?=$row['itemprice'];?>" name="itemprice"><br>
                    <label for="">Date Recieved</label><br>
                    <input type="date" value="<?=$row['daterecieved'];?>" name="daterecieved"><br>
                    <label for="">Image</label><br>
                    <input type="file" name="image"><br>
                    <button type="submit" name="submit">Update</button>
                   
                </form>
                <?php } ?>
            </div>
        </div>
    </body>
</html>