﻿Imports System.IO.File
Imports System.IO.FileStream
Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'StudentsRecordSystemDataSet.member' table. You can move, or remove it, as needed.
        Me.MemberTableAdapter.Fill(Me.StudentsRecordSystemDataSet.member)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        MemberBindingSource.AddNew()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        On Error GoTo SaveErr
        MemberBindingSource.EndEdit()
        MemberTableAdapter.Update(StudentsRecordSystemDataSet.member)
        MessageBox.Show("Successfully Save!!")
SaveErr:
        Exit Sub
    End Sub

    Private Sub SearchToolStripButton_Click(sender As Object, e As EventArgs) Handles SearchToolStripButton.Click
        Try
            Me.MemberTableAdapter.Search(Me.StudentsRecordSystemDataSet.member, FIRSTNAMEToolStripTextBox.Text)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        MemberBindingSource.RemoveCurrent()
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        MemberBindingSource.MovePrevious()
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        MemberBindingSource.MoveNext()
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        MemberBindingSource.MoveFirst()
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        MemberBindingSource.MoveLast()
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        Me.Close()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        On Error GoTo err
        OpenFileDialog1.ShowDialog()
        TextBox5.Text = OpenFileDialog1.FileName
Err:
        Exit Sub
    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles TextBox5.TextChanged
        If (System.IO.File.Exists(TextBox5.Text)) Then
            PictureBox1.Image = Image.FromFile(TextBox5.Text)

        End If
        If TextBox5.Text = "" Then
            PictureBox1.Hide()
        Else
            PictureBox1.Show()
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        MemberTableAdapter.Search(StudentsRecordSystemDataSet.member, TextBox1.Text)
    End Sub
End Class
