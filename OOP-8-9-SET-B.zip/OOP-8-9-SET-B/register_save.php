<?php
    include "dbconn.php";
    if(isset($_POST['submit'])){
        $idnumber=$_POST['idnumber'];
        $fname=$_POST['fname'];
        $mi=$_POST['mi'];
        $lname=$_POST['lname'];
        $gender=$_POST['gender'];
        $course=$_POST['course'];
        $contact=$_POST['contact'];
        $address=$_POST['address'];
        $file_name=$_FILES['profile']['name'];
        $file_temp=$_FILES['profile']['tmp_name'];
        $file_size=$_FILES['profile']['size'];
        $location='upload/'.$file_name;

        if($file_size <=1000000){
            move_uploaded_file($file_temp,$location);
            $sql="INSERT INTO tbl_student(idnumber,fname,mi,lname,gender,course,contact,address,profile)
            VALUES('$idnumber','$fname','$mi','$lname','$gender','$course','$contact','$address','$location')";
            if($conn->query($sql)){
                $_SESSION['success']='Successfully saved!';
            }else{
                $_SESSION['error']='Error to save!';
            }
        }else{
            $_SESSION['error']='Image is to large to save';
        }
    }
    header("location:index.php");
?>