<?php
    session_start();
    $conn =new mysqli("localhost","root","","crud_db");
?>