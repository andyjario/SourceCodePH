﻿Imports System.Data.SqlClient
Public Class EmpSetting
    Shared Property EmpSettingForm As String
    Private Sub EmpSetting_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBox1.Text = EmpSettingForm
        Dim query As String = "SELECT * FROM UserTable WHERE USERNAME = '" & TextBox1.Text & "'"
        Using con As SqlConnection = New SqlConnection("Data Source=.;Initial Catalog=attendanceDB;Integrated Security=True;Pooling=False")
            Using cmd As SqlCommand = New SqlCommand(query, con)
                Using da As New SqlDataAdapter()
                    da.SelectCommand = cmd
                    Using dt As New DataTable()
                        con.Open()
                        da.Fill(dt)
                        If dt.Rows.Count > 0 Then
                            TextBox1.Text = dt.Rows(0)(1).ToString()
                            TextBox2.Text = dt.Rows(0)(2).ToString()
                        Else
                            TextBox1.Text = ""
                            TextBox2.Text = ""
                        End If
                    End Using
                    con.Close()
                End Using
            End Using
        End Using

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim USERNAME As String = TextBox1.Text
        Dim PASSWORD As String = TextBox3.Text
        If TextBox3.Text = Nothing Then
            MessageBox.Show("Please enter the required fields!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            Try
                Dim updatequery As String = "UPDATE UserTable SET PASSWORD =@PASSWORD WHERE USERNAME=@USERNAME"
                Using updatecon As SqlConnection = New SqlConnection("Data Source=.;Initial Catalog=attendanceDB;Integrated Security=True;Pooling=False")
                    Using cmdupdate As New SqlCommand(updatequery, updatecon)
                        cmdupdate.Parameters.AddWithValue("@USERNAME", USERNAME)
                        cmdupdate.Parameters.AddWithValue("@PASSWORD", PASSWORD)
                        updatecon.Open()
                        cmdupdate.ExecuteNonQuery()
                        MessageBox.Show("Password has been changed successfully", "Sucess", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        updatecon.Close()
                    End Using
                    Application.Restart()
                End Using
            Catch ex As Exception
                MessageBox.Show("OPPS, WE HAVE ERROR FOUND", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
End Class