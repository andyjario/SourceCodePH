﻿Imports System.Data.SqlClient
Public Class LoginForm
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim USERNAME As String = TextBox1.Text
        Dim PASSWORD As String = TextBox2.Text

        If TextBox1.Text = "" Or TextBox2.Text = "" Then
            MessageBox.Show("PLEASE YOUR CRENDENTIALS", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            'Dim LogQuery As String = "SELECT USERNAME, PASSWORD, USERTYPE, USTATUS FROM UserTable WHERE USERNAME=@USERNAME AND PASSWORD=@PASSWORD AND USTATUS='Active'"
            Dim LogQuery As String = "SELECT USERNAME, PASSWORD, USERTYPE, USTATUS FROM UserTable WHERE USERNAME=@USERNAME AND PASSWORD=@PASSWORD AND USTATUS='Active' UNION SELECT USERNAME, PASSWORD, USERTYPE, USTATUS FROM adminTable WHERE USERNAME=@USERNAME AND PASSWORD=@PASSWORD AND USTATUS='Active'"
            Using con As SqlConnection = New SqlConnection("Data Source=.;Initial Catalog=attendanceDB;Integrated Security=True;Pooling=False")
                Using cmd As SqlCommand = New SqlCommand(LogQuery, con)

                    cmd.Parameters.AddWithValue("@USERNAME", USERNAME)
                    cmd.Parameters.AddWithValue("@PASSWORD", PASSWORD)

                    Dim da As New SqlDataAdapter(cmd)
                    Dim myTable As New DataTable

                    con.Open()
                    da.Fill(myTable)
                    If myTable.Rows.Count > 0 Then
                        Dim message As String = "You have successfully login. Please click ok to proceed."
                        Dim caption As String = "Success"
                        Dim result = MessageBox.Show(message, caption, MessageBoxButtons.OK, MessageBoxIcon.Information)
                        If myTable.Rows(0)("USERTYPE") = "Admin" Then
                            Dim AdminDboard As New AdminDashboard
                            AdminDashboard.AdminDboard = TextBox1.Text
                            AdminDashboard.Show()

                        ElseIf myTable.Rows(0)("USERTYPE") = "User" Then
                            Dim UserDashboard As New EmpDashboard
                            EmpDashboard.UserDashboard = TextBox1.Text
                            EmpDashboard.Show()

                        End If
                        TextBox1.Clear()
                        TextBox2.Clear()
                    Else
                        MessageBox.Show("Username or password does not match or found in database.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If
                    con.Close()
                End Using
            End Using
        End If
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TextBox1.Clear()
        TextBox2.Clear()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim message As String = "DO YOU WANT TO EXIT?"
        Dim caption As String = "EXIT"
        Dim result = MessageBox.Show(message, caption, MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If (result = DialogResult.Yes) Then
            Application.Exit()
        ElseIf (result = DialogResult.Yes) Then
            Me.Close()
        End If
    End Sub
End Class
