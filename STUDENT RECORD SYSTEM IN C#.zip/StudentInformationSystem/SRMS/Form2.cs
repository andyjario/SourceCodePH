﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SRMS
{
    public partial class WelcomePage : Form
    {
        public string AdminName;
        public WelcomePage()
        {
            InitializeComponent();
        }

 
        private void WelcomePage_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'studentRecordDBDataSet.studentTable' table. You can move, or remove it, as needed.
            this.studentTableTableAdapter.Fill(this.studentRecordDBDataSet.studentTable);
            label1.Text = AdminName;
            
        }
        
         private void BindData()
         {
             SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=StudentRecordDB;Integrated Security=True");
             con.Open();
             SqlCommand cmd = new SqlCommand("SELECT * FROM studentTable",con);
             SqlDataAdapter sda = new SqlDataAdapter(cmd);
             DataTable dt = new DataTable();
     
             sda.Fill(dt);
             dataGridView1.DataSource = dt;

         }
        private void button1_Click(object sender, EventArgs e)
        {
            //if (textBox1.Text == "")
            //{
            //    MessageBox.Show("Enter the required fields!", "Required", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            //}
            //else
            //{
            //    try
            //    {
            //        SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=StudentRecordDB;Integrated Security=True");
            //        con.Open();
            //        SqlCommand cmd = new SqlCommand("SELECT * FROM studentTable WHERE ID=@ID",con);
            //        cmd.Parameters.AddWithValue("@ID",int.Parse(textBox1.Text));
            //        SqlDataReader da = cmd.ExecuteReader();

            //        while (da.Read())
            //        {
            //            textBox2.Text = da.GetValue(0).ToString();
            //            textBox3.Text = da.GetValue(1).ToString();
            //        }
            //        con.Close();
            //        MessageBox.Show("1 record found!");
            //    }
            //    catch (Exception ex)
            //    {
            //        MessageBox.Show(ex.Message);
            //    }
            //}
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox6.Text = "";
            textBox7.Text = "";
            textBox8.Text = "";
            textBox9.Text = "";
            textBox10.Text = "";
            textBox11.Text = "";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text != "")
            {
                SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=StudentRecordDB;Integrated Security=True");
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM studentTable WHERE ID=@ID", con);
                cmd.Parameters.AddWithValue("@ID", int.Parse(textBox1.Text));
                SqlDataReader da = cmd.ExecuteReader();

                while (da.Read())
                {
                    textBox2.Text = da.GetValue(0).ToString();
                    textBox3.Text = da.GetValue(1).ToString();
                    textBox4.Text = da.GetValue(2).ToString();
                    textBox5.Text = da.GetValue(3).ToString();
                    textBox6.Text = da.GetValue(4).ToString();
                    textBox7.Text = da.GetValue(5).ToString();
                    textBox8.Text = da.GetValue(6).ToString();
                    textBox9.Text = da.GetValue(7).ToString();
                    textBox10.Text = da.GetValue(8).ToString();
                    textBox11.Text = da.GetValue(9).ToString();

                }
                con.Close();
                //MessageBox.Show("1 record found!");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Please enter first the student in search box","REQUIRED",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            }
            else
            {
                try
                {
                    SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=StudentRecordDB;Integrated Security=True");
                    
                    SqlCommand cmd = new SqlCommand("UPDATE studentTable SET FIRSTNAME=@FIRSTNAME,LASTNAME=@LASTNAME,MIDDLENAME=@MIDDLENAME,GENDER=@GENDER,AGE=@AGE,CONTACT=@CONTACT,ADDRESS=@ADDRESS,COURSE=@COURSE,DEPARTMENT=@DEPARTMENT WHERE ID=@ID",con);
                    cmd.Parameters.AddWithValue("@ID", textBox2.Text);
                    cmd.Parameters.AddWithValue("@FIRSTNAME", textBox3.Text);
                    cmd.Parameters.AddWithValue("@LASTNAME", textBox4.Text);
                    cmd.Parameters.AddWithValue("@MIDDLENAME", textBox5.Text);
                    cmd.Parameters.AddWithValue("@GENDER", textBox6.Text);
                    cmd.Parameters.AddWithValue("@AGE", textBox7.Text);
                    cmd.Parameters.AddWithValue("@CONTACT", textBox8.Text);
                    cmd.Parameters.AddWithValue("@ADDRESS", textBox9.Text);
                    cmd.Parameters.AddWithValue("@COURSE", textBox10.Text);
                    cmd.Parameters.AddWithValue("@DEPARTMENT", textBox11.Text);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Successfully updated!", "SUCCESS",MessageBoxButtons.OK,MessageBoxIcon.Information);
                    BindData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    textBox1.Text = "";
                    textBox2.Text = "";
                    textBox3.Text = "";
                    textBox4.Text = "";
                    textBox5.Text = "";
                    textBox6.Text = "";
                    textBox7.Text = "";
                    textBox8.Text = "";
                    textBox9.Text = "";
                    textBox10.Text = "";
                    textBox11.Text = "";
                    BindData();
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "" || textBox3.Text == "" || textBox4.Text == "" || textBox5.Text == "" || textBox6.Text == "" || textBox7.Text == "" || textBox8.Text == "")
            {
                MessageBox.Show("Required field");
            }
            else
            {
                try
                {
                    SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=StudentRecordDB;Integrated Security=True");
                    con.Open();
                    SqlCommand cmd = new SqlCommand("SELECT * FROM studentTable WHERE ID=@ID", con);
                    cmd.Parameters.AddWithValue("@ID", int.Parse(textBox2.Text));
                    SqlDataAdapter sda = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    sda.Fill(dt);
                    cmd.ExecuteNonQuery();
                    
                    if (dt.Rows.Count > 0)
                    {
                        MessageBox.Show("Student ID has already taken, please enter the unique id", "Required", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    }
                    else
                    {
                       
                        SqlCommand cmd1 = new SqlCommand("INSERT INTO studentTable (ID,FIRSTNAME,LASTNAME,MIDDLENAME,GENDER,AGE,CONTACT,ADDRESS,COURSE,DEPARTMENT)VALUES(@ID,@FIRSTNAME,@LASTNAME,@MIDDLENAME,@GENDER,@AGE,@CONTACT,@ADDRESS,@COURSE,@DEPARTMENT)", con);
                        cmd1.Parameters.AddWithValue("@ID", textBox2.Text);
                        cmd1.Parameters.AddWithValue("@FIRSTNAME", textBox3.Text);
                        cmd1.Parameters.AddWithValue("@LASTNAME", textBox4.Text);
                        cmd1.Parameters.AddWithValue("@MIDDLENAME", textBox5.Text);
                        cmd1.Parameters.AddWithValue("@GENDER", textBox6.Text);
                        cmd1.Parameters.AddWithValue("@AGE", textBox7.Text);
                        cmd1.Parameters.AddWithValue("@CONTACT", textBox8.Text);
                        cmd1.Parameters.AddWithValue("@ADDRESS", textBox9.Text);
                        cmd1.Parameters.AddWithValue("@COURSE", textBox10.Text);
                        cmd1.Parameters.AddWithValue("@DEPARTMENT", textBox11.Text);
                        cmd1.ExecuteNonQuery();
                        MessageBox.Show(textBox3.Text + ", " + textBox4.Text + " " + "Successfully inserted!", "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        textBox1.Text = "";
                        textBox2.Text = "";
                        textBox3.Text = "";
                        textBox4.Text = "";
                        textBox5.Text = "";
                        textBox6.Text = "";
                        textBox7.Text = "";
                        textBox8.Text = "";
                        textBox9.Text = "";
                        textBox10.Text = "";
                        textBox11.Text = "";
                        BindData();
                    }
                    con.Close();
                }

                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox2.Text =="")
            {
                MessageBox.Show("Please input ID first!!");
            }
            try {
                SqlConnection con = new SqlConnection("Data Source=.;Initial Catalog=StudentRecordDB;Integrated Security=True");

                SqlCommand cmd = new SqlCommand("DELETE FROM studentTable WHERE ID=@ID", con);
                cmd.Parameters.AddWithValue("@ID", textBox2.Text);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Successfully DELETED!", "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                BindData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";
                textBox6.Text = "";
                textBox7.Text = "";
                textBox8.Text = "";
                textBox9.Text = "";
                textBox10.Text = "";
                textBox11.Text = "";
                BindData();
            }
        }

    }
}
