<html>
    <head>
        <title>Inventory Management System</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <div class="container">
            <div class="menubar">
                <ol>
                    <li><a href="record.php">Record</a></li>
                    <li><a href="index.php">Add New</a></li>
                    <li><a href="">Brand</a></li>
                    <li><a href="">Category</a></li>
                    <li><a href="">Search</a></li>
                    <li><a href="">Logout</a></li>
                </ol>
            </div>
            <div class="addForm">
                <form action="item_save.php" method="POST" enctype="multipart/form-data">
                    <label for="">Item Id</label><br>
                    <input type="text" name="itemid"><br>
                    <label for="">Item Brand</label><br>
                    <input type="text" name="itembrand"><br>
                    <label for="">Item Name</label><br>
                    <input type="text" name="itemname"><br>
                    <label for="">Item Description</label><br>
                    <input type="text" name="itemdesc"><br>
                    <label for="">Item Quantity</label><br>
                    <input type="text" name="itemqty"><br>
                    <label for="">Item Price</label><br>
                    <input type="text" name="itemprice"><br>
                    <label for="">Date Recieved</label><br>
                    <input type="date" name="daterecieved"><br>
                    <label for="">Image</label><br>
                    <input type="file" name="image"><br>
                    <button type="submit" name="submit">Submit</button>
                    <button type="reset">Cancel</button>
                </form>
            </div>
        </div>
    </body>
</html>