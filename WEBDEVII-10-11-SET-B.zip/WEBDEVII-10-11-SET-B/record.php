<html>
    <head>
        <title>Inventory Management System</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <div class="container">
            <div class="menubar">
                <ol>
                    <li><a href="record.php">Record</a></li>
                    <li><a href="index.php">Add New</a></li>
                    <li><a href="">Brand</a></li>
                    <li><a href="">Category</a></li>
                    <li><a href="">Search</a></li>
                    <li><a href="">Logout</a></li>
                </ol>
            </div>
            <div class="addForm">
                <table>
                    <thead>
                        <tr>
                            <th>Item Id</th>
                            <th>Item Brand</th>
                            <th>Item Name</th>
                            <th>Item Description</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                        include "dbconn.php";
                        $sql="SELECT * FROM tbl_supply";
                        $query=$conn->query($sql);
                        $count=1;
                        while($row=$query->fetch_assoc()){
                    ?>
                        <tr>
                            <td><?=$row['itemid']?></td>
                            <td><?=$row['itembrand']?></td>
                            <td><?=$row['itemname']?></td>
                            <td><?=$row['itemdesc']?></td>
                        </tr>
                    <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </body>
</html>