# Pharmacy Inventory System
C++ object-oriented based desktop application to manage the storage of medicines. 
This system served as an administrative programme and users (Admin) need to key in 
password to login to the system. This system allows users to add, update, delete, view
 and search the medicine records according to medicine id number. User can also add and 
alter the category and stock of medicine. The system reduces the manual workload of inventory management. 
